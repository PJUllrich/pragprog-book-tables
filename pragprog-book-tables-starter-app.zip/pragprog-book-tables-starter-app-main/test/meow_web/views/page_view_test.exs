defmodule MeowWeb.PageViewTest do
  use MeowWeb.ConnCase, async: true
end
